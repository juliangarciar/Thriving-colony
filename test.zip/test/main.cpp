#include <iostream>

#include <OBDEngine.h>
#include <ResourceManager/ResourceManager.h>
#include <OBDShaderProgram.h>

#include <GLFW/glfw3.h>

int main() {
    ResourceManager *rm = new ResourceManager();

    // Initialise GLFW
	if(!glfwInit()) {
		std::cout << "Failed to initialize GLFW" << std::endl;
		return -1;
	}

	glfwWindowHint(GLFW_SAMPLES, 4);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 1);
	glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE); // To make MacOS happy; should not be needed
	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

	// Open a window and create its OpenGL context
	GLFWwindow* window = glfwCreateWindow(1024, 768, "Tutorial 07 - Model Loading", NULL, NULL);
	if( window == NULL ){
		std::cout << "Failed to open GLFW window." << std::endl;
		glfwTerminate();
		return -1;
	}
	glfwMakeContextCurrent(window);

    std::cout << "Using OpenGL version: " <<  glfwGetWindowAttrib(window, GLFW_CONTEXT_VERSION_MAJOR) << "." << glfwGetWindowAttrib(window, GLFW_CONTEXT_VERSION_MINOR) << std::endl;

    OBDEngine *re = new OBDEngine();

    re -> Init();

	re -> createShaderProgram("defaultProgram", "../media/shaders/vertexShader.glsl", "../media/shaders/fragmentShader.glsl");

	re -> setCurrentShaderProgram("defaultProgram");

    OBDLight *light = re -> createLight(OBDColor(1, 1, 1), 1);

    OBDCamera *camera = re -> createCamera();

	camera->setCameraPosition(glm::vec3(10, 10, 10));
	
	ResourceIMG *img = (ResourceIMG*)rm->getResource("../media/testBuilding/wall_kaonov_Base_Color.bmp", true);

	// malla 1
	OBDMesh *mesh = re -> createMesh("../media/testBuilding/wall.obj");
	mesh->setTexture("Wall_Cube.003", OBDEnums::TextureTypes::TEXTURE_DIFFUSE, img);

	// malla 2
	OBDMesh *mesh2 = re -> createMesh("../media/testBuilding/wall.obj");
	mesh2->setTexture("Wall_Cube.003", OBDEnums::TextureTypes::TEXTURE_DIFFUSE, img);
	mesh2 -> rotate(1.00, -180.00, -3.00, 0.0);
	mesh2 -> translate(-7.00, 2.50, 4.50);
	mesh2 -> scale(0.50,0.50,0.50);

	// malla 3
	OBDMesh *mesh3 = re -> createMesh("../media/testBuilding/wall.obj");
	//mesh3->setTexture("Wall_Cube.003", OBDEnums::TextureTypes::TEXTURE_AMBIENT, img);
	mesh3 -> translate(5.00, 0.00, 2.00);
	mesh3 -> scale(1, 1, 1);
	mesh3 -> rotate(0.00, 90.00, 0.00, 0.0);

	//bucle
	int i = -10.0;
	while (glfwGetKey(window, GLFW_KEY_ESCAPE ) != GLFW_PRESS && glfwWindowShouldClose(window) == 0){
		//mesh3 -> translate(0, 0.01, 0);
		light -> setPosition(glm::vec3(i, 10.00, i));
		i++;
		if (i > 10.0) i = -10.0;
		// Engine draw
        re -> draw();
		// Swap buffers
		glfwSwapBuffers(window);
		glfwPollEvents();
    }

    return 0;
}
