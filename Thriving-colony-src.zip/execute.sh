#!/bin/bash
./bin/ThrivingColony