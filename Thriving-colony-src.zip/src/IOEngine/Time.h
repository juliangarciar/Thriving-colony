#ifndef TIME_H
#define TIME_H

class Time {

    public:
        Time();
        ~Time();
        
    private:
};

#endif