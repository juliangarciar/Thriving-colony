#include "Time.h"

Time::Time() {
    
}

Time::~Time() {
    
}