#include "Animation.h"

Animation::Animation() {
    
}

Animation::~Animation() {
    
}