#ifndef SPRITE_H
#define SPRITE_H

class Sprite {

    public:
        Sprite();
        ~Sprite();
        
    private:
};

#endif