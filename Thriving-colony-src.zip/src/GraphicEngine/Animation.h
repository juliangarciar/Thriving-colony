#ifndef ANIMATION_H
#define ANIMATION_H

class Animation {
    
    public:
        Animation();
        ~Animation();

    private:
};

#endif