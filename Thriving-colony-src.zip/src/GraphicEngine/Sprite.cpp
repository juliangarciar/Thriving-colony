#include "Sprite.h"

Sprite::Sprite() {
    
}

Sprite::~Sprite() {
    
}