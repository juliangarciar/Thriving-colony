#ifndef FONT_H
#define FONT_H

class Font {

    public:
        Font();
        ~Font();
        
    private:
};

#endif