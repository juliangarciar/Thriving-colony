#include "Font.h"

Font::Font() {
    
}

Font::~Font() {
    
}