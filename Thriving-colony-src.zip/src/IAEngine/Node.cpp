#include "Node.h"
#include "../IA.h"

Node::Node() {

}

Node::~Node() {
    
}

void Node::question(){}
