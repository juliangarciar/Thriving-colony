#include "ArmyNode.h"
#include "UnitNode.h"
#include "BuildingNode.h"
#include "../IA.h"

ArmyNode::ArmyNode(Node *fatherPnt) : Node() {
    father = fatherPnt;
    children = new Node*[2];
    children[0] = new UnitNode(this);
    children[1] = new BuildingNode(this);
}

ArmyNode::~ArmyNode(){
    delete father;
    delete[] children;
}

void ArmyNode::question() {
    //First subbranch: Units
    if (IA::getInstance() -> getTree() -> getNeedSoldiers()){
        children[0] -> question();
    } else {
        //Second subbranch: Buildings
        if (IA::getInstance() -> getTree() -> getNeedBuildings()) {
            children[1] -> question();
        }
    }
}