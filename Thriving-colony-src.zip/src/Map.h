#ifndef MAP_H
#define MAP_H

class Map {
    
    public:
        Map();
        ~Map();

    private:
};

#endif