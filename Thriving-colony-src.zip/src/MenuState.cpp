#include "MenuState.h"

MenuState::MenuState() : State() {
    
}

MenuState::~MenuState() {
    
}

void MenuState::Init(){

}

void MenuState::Input(){

}

void MenuState::Update(){

}

void MenuState::Render(){

}

void MenuState::CleanUp(){

}