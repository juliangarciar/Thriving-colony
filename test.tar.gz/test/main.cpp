#include <iostream>

#include <OBDEngine.h>
#include <ResourceManager/ResourceManager.h>
#include <OBDShaderProgram.h>

#include <GLFW/glfw3.h>

int main() {
    ResourceManager *rm = new ResourceManager();

    // Initialise GLFW
	if(!glfwInit()) {
		std::cout << "Failed to initialize GLFW" << std::endl;
		return -1;
	}

	glfwWindowHint(GLFW_SAMPLES, 4);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
	glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE); // To make MacOS happy; should not be needed
	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

	// Open a window and create its OpenGL context
	GLFWwindow* window = glfwCreateWindow(1024, 768, "Tutorial 07 - Model Loading", NULL, NULL);
	if( window == NULL ){
		std::cout << "Failed to open GLFW window. If you have an Intel GPU, they are not 3.3 compatible. Try the 2.1 version of the tutorials." << std::endl;
		glfwTerminate();
		return -1;
	}
	glfwMakeContextCurrent(window);

    OBDEngine *re = new OBDEngine();

    re -> Init();

	re -> createShaderProgram("defaultProgram", "vertexShader.glsl", "fragmentShader.glsl");

	re -> setCurrentShaderProgram("defaultProgram");

    OBDLight *light = re -> createLight(OBDColor(1, 1, 1, 1), 50);

    OBDCamera *camera = re -> createCamera();

	camera->setCameraPosition(glm::vec3(10, 10, 10));
	// malla 1
	OBDMesh *mesh = re -> createMesh("wall.obj");

	//TMesh *meshHandler = mesh -> getMesh("Wall_Cube.003");
	
	ResourceIMG *img = (ResourceIMG*)rm->getResource("wall_kaonov_Base_Color.bmp", true);

	mesh->setTexture("Wall_Cube.003", OBDEnums::TextureTypes::TEXTURE_AMBIENT, img);

	// malla 2

	OBDMesh *mesh2 = re -> createMesh("wall.obj");

	//TMesh *meshHandler2 = mesh -> getMesh("Wall_Cube.003");

	mesh2->setTexture("Wall_Cube.003", OBDEnums::TextureTypes::TEXTURE_AMBIENT, img);
    
	mesh2 -> rotate(1.00, -180.00, -3.00 );
	mesh2 -> translate(-7.00, 2.50, 4.50);
	mesh2 -> scale(0.50,0.50,0.50);

	// malla 3

	OBDMesh *mesh3 = re -> createMesh("wall.obj");

	//TMesh *meshHandler3 = mesh -> getMesh("Wall_Cube.003");

	mesh3->setTexture("Wall_Cube.003", OBDEnums::TextureTypes::TEXTURE_AMBIENT, img);
    
	
	mesh3 -> translate(5.00, -1.50, 2.00);
	mesh3 -> scale(1.50,1.50,1.50);
	mesh3 -> rotate(0.00, 90.00, 0.00 );
	//bucle
	while (glfwGetKey(window, GLFW_KEY_ESCAPE ) != GLFW_PRESS && glfwWindowShouldClose(window) == 0){
		// Engine draw
        re -> draw();
		mesh -> rotate(0.00, 0.01, 0.00);
		// Swap buffers
		glfwSwapBuffers(window);
		glfwPollEvents();
    }

    return 0;
}
